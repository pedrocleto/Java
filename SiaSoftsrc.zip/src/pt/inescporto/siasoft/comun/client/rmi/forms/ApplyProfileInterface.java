package pt.inescporto.siasoft.comun.client.rmi.forms;

import javax.swing.tree.TreePath;

/**
 * <p>Title: SIASoft</p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: INESC Porto</p>
 *
 * @author not attributable
 * @version 0.1
 */
public interface ApplyProfileInterface {
  public void applyProfile(TreePath[] treePath, Integer app);
}
